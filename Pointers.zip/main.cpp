/*
Name: Kendrick Nguyen
Date: 3 March 2021
Class: CECS 275
Desc:The purpose of this lab is to create a program that dynamically allocates an array
*/
#include <iostream>
using namespace std;
#include <cstdlib> 
#include <ctime>
#include "CheckInput.h"

/* Passes user input
 * @param size gives the function the size of the group of numbers
 * @return the array to the main
 */
int *Populate(int size){
  srand(time(NULL));
  int randNum;
  int *Arr = new int[size];
  for(int i = 0; i < size; i++){
    randNum = rand() % 100 + 1;
    Arr[i] = randNum;
  }
  return Arr;
}

/* Passes the ptr and size and then displays the array
 * @param *ptrArr is the pointer
 * @param size gives the function the size of the group of numbers
 */
void Display(int *ptrArr, int size){
  for(int i = 0; i < size; i++){
    cout << ptrArr[i] << " ";
    if(i % 10 == 9){
      cout << endl;
    }
  }
  cout << endl;
  cout <<endl;
}

/* Passes two ints and swaps them 
 * @param num1 takes value of num2
 * @param num2 takes value of num1
 */
void Swap(int &num1, int &num2){
  int tempVar = num1;     //holds onto num1 value
  num1 = num2;            //changes num1 to num2
  num2 = tempVar;         //changes num2 to num1
}

/* Passes pointer and size, then sorts it from least to greatest
 * @param *ptrArr is the pointer
 * @param size gives the function the size of the group of numbers
 * Notes: Had help, the do let's us execute the loop, and if it returns true, it will repeat the loop
 */
void Sort(int *ptrArr, int size){
  bool swapped = false;
  do{                                 
  swapped = false;
  for(int i = 0; i < size - 1; i++){
    if(ptrArr[i] > ptrArr[i + 1]){
      int swap = ptrArr[i];
      ptrArr[i] = ptrArr[i + 1];
      ptrArr[i + 1] = swap;
      swapped = true;
    }
  }
  }
  while(swapped);
}

/* Passes pointer and size to shuffle the entire array
 * @param *ptrArr is the pointer
 * @param size gives the function the size of the group of numbers
 * Desc: Honestly did not understand how to do this at first, looked this up on some c++ websites, also had help, essentially, increase the size by 2 to make sure it is more shuffled.
 */
void Shuffle(int *ptrArr, int size){
  srand(time(NULL));
  int random1;
  int random2;
  for(int i = 0; i < 2 * size; i++){
    random1 = rand() % size;
    random2 = rand() % size;
    Swap(ptrArr[random1], ptrArr[random2]);
  }
}

/* Passes pointer and size to get max value
 * @param *ptrArr is the pointer used 
 * @param gives the function the size of the group of numbers
 * @return max gives us the max value of the array
 */
int Max(int *ptrArr, int size){
  int max = ptrArr[0];
  for(int i = 1; i < size; i++){
    if(max < ptrArr[i]){
      max = ptrArr[i];
    }
  }
  return max;
}

/* Displays the menu to the user
 * @return userIn for choice
 */
int menu(){
  int userIn;                                           // init user input 
  cout << "1. Display"<<endl;
  cout << "2. Sort"<<endl;
  cout << "3. Shuffle"<<endl;
  cout << "4. Max"<<endl;
  cout << "5. Quit"<<endl;
  cout << "Select an option (1-5): ";
  userIn = getIntRange(1,5);                            // The user can only choose 5 options
  cout << endl;
  return userIn;
}

int main(){
  cout << "Enter the size of your number (1-100): ";
  int size = getPositiveInt();
  cout << endl;
  int *ptrArr = Populate(size);
  int sel;
  while(1){
    sel = menu();
    if(sel == 1){
      Display(ptrArr, size);
    }
    else if(sel == 2){
      Sort(ptrArr, size);
    }
    else if(sel == 3){
      Shuffle(ptrArr, size);
    }
    else if(sel == 4){
      int max = Max(ptrArr, size);
      cout << "The max value of the list is: " << max << endl;
      cout << endl;
    }
    else if(sel == 5){
      cout << "You have the suds from Spongebob, and so you are now out of commission."<<endl;
      cout << "You quit.";
      break;
    }
  }
  return 0;
}